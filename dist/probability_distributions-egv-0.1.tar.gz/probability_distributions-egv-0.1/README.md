# probability-distributions package

This project provides classes for calculating and visualizing Gaussian and Binominal distributions.

# Installation

Dependencies

requires:
python == 3.9
matplotlib == 3.4.2
numpy == 1.21.1

# Acknowledgements
Must give credit to Udacity for providing detailed instructions for creating this project.
