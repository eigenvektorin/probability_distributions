from setuptools import setup

setup(name='probability_distributions-egv',
        version='0.1',
        description='probability distributions-egv',
      packages=['probability_distributions-egv'],
      zip_safe=False)